# Run lammps using the following 3 commands:
# (assuming "lmp_mpi" is the name of your LAMMPS binary)

lmp_mpi -i run.in.min
lmp_mpi -i run.in.stage1
lmp_mpi -i run.in.stage2

